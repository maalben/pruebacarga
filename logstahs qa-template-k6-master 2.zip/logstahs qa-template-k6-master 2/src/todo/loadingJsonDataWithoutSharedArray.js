//https://k6.io/docs/javascript-api/init-context/open/
import { sleep } from 'k6';

const users = JSON.parse(open('./files/users.json')); // consider using SharedArray for large files

export default function () {
  const user = users[__VU - 1];
  console.log(`${user.username}, ${user.password}`);
  sleep(3);
}