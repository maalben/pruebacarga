//https://k6.io/docs/javascript-api/k6-html/selection/selection-attr/
import { parseHTML } from 'k6/html';
import http from 'k6/http';

export default function () {
  const res = http.get('https://k6.io');
  const doc = parseHTML(res.body);
  console.log(doc);
  const langAttr = doc.find('html').attr('prefix');
  console.log(langAttr);
}
