//https://k6.io/docs/javascript-api/k6-http/response/response-html/
import http from 'k6/http';

export default function () {
  const res = http.get('https://stackoverflow.com');

  const doc = res.html();
  doc
    .find('link')
    .toArray()
    .forEach(function (item) {
      console.log(item.attr('href'));
    });
}
