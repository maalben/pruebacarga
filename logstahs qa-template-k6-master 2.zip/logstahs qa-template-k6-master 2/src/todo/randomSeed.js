//https://k6.io/docs/javascript-api/k6/randomseed/
import { randomSeed } from 'k6';

export const options = {
  vus: 5,
  duration: '5s',
};

export default function () {
  randomSeed(123456789);
  const rnd = Math.random();
  console.log(rnd);
}
