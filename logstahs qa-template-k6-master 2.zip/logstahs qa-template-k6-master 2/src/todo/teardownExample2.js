//https://k6.io/docs/using-k6/test-lifecycle/#setup-and-teardown-stages

export function setup() {
    return { v: 2 };
  }
  
  export default function (data) {
    console.log(JSON.stringify(data));
  }
  
  export function teardown(data) {
    if (data.v != 1) {
      throw new Error('incorrect data: ' + JSON.stringify(data));
    }
  }
  