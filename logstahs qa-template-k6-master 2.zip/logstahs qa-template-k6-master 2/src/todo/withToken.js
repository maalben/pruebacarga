import http from 'k6/http';
//import * as globals from '../Globals/Logger.js'
import { sleep, check, group, fail } from 'k6';
//import { Counter } from 'k6/metrics';

// A simple counter for http requests

export function setup() {
   globals.headersLogs();
}

//export const requests = new Counter('http_reqs');

// you can specify stages of your test (ramp up/down patterns) through the options object
// target is the number of VUs you are aiming for

export const options = {
  stages: [
    { target: 1, duration: '3s' },
/*     { target: 3, duration: '1m' },
    { target: 0, duration: '1m' }, */
  ]
/*   ,
  thresholds: {
    http_reqs: ['count < 100'],
  }, */
};

export default function () {
    let token;
    group("1 - Get token", function() {token = getTokenServices()});
    group("2 - Credit Application", function(){postCreditApplication(token)});
}

function getTokenServices(){
  let url = 'https://af2iggk3wl.execute-api.us-east-2.amazonaws.com/v1/api/personal/sessions';
  let response = http.get(url);

  let token = response.json().data.sessionId
  console.log("Primero: "+token);
  console.log("Status code: " + response.status);
  console.log("ResponseCode: " + response.json().responseCode);
  console.log("Message: " + response.json().message);
  console.log("------------------------------------------------------");
  check(response, {
    'status is 200': (r) => r.status === 200,
    'responseCode': (r) => r.json().responseCode === 1000,
    'message': (r) => r.json().message === "Operation performed successfully",
  });
  return token;
};

function postCreditApplication(valueToken){
  const url = 'https://af2iggk3wl.execute-api.us-east-2.amazonaws.com/v1/api/personal/credit-application';
    let headers = { 'Content-Type': 'application/json',
                    'x-session-id': valueToken };
    let data = 
      {
        "personal": {
          "identification": {
            "type": {
              "id": "CC",
              "value": "Cédula de ciudadanía"
            },
            "document": ""
          },
          "expeditionDate": "2002-02-02",
          "expeditionCity": {
            "name": "ARMENIA",
            "daneCode": "63001",
            "departmentDaneCode": "63",
            "departmentName": "QUINDIO"
          },
          "birthDate": "1980-03-03",
          "birthCity": {
            "name": "CALI",
            "daneCode": "76001",
            "departmentDaneCode": "76",
            "departmentName": "VALLE DEL CAUCA"
          },
          "civilStatus": {
            "id": "2",
            "value": "Casado"
          },
          "gender": {
            "id": "1",
            "value": "Masculino"
          }
        },
        "housing": {
          "city": {
            "name": "CARTAGENA DE INDIAS",
            "daneCode": "13001",
            "departmentDaneCode": "13",
            "departmentName": "BOLIVAR"
          },
          "address": "Dirección de residencia actual",
          "alternativeAddress": "Complemento dirección de residencia actual",
          "type": {
            "id": "3",
            "value": "Propia"
          },
          "yearOfLiving": 8
        },
        "work": {
          "educationalLevel": {
            "id": "5",
            "value": "Postgrado"
          },
          "activity": {
            "id": "1",
            "value": "Empleado"
          },
          "career": {
            "id": "12230",
            "value": "Directores y gerentes de ingeniería, investigación y desarrollo"
          },
          "company": {
            "sector": {
              "id": "2",
              "value": "Privado"
            },
            "name": "Banco de Occidente",
            "activity": {
              "id": "5",
              "value": "Financiero"
            },
            "city": {
              "name": "CALI",
              "daneCode": "76001",
              "departmentDaneCode": "76",
              "departmentName": "VALLE DEL CAUCA"
            },
            "address": "Dirección empresa",
            "alternativeAddress": "Complemento dirección empresa",
            "phone": "3164440038",
            "position": "Gerente de TI",
            "entryDate": "2009-12-05",
            "contractType": {
              "id": "02",
              "value": "Término indefinido"
            }
          }
        },
        "financial": {
          "income": "30500000",
          "additionalIncome": "2800000",
          "discounts": "5600000",
          "expenses": "6000000",
          "dependants": 1,
          "totalAssets": "1550000000",
          "totalLiabilities": "120000000",
          "properties": {
            "status": true,
            "current": "1200000000"
          },
          "vehicles": {
            "status": true,
            "current": "230000000"
          },
          "otherAssets": {
            "status": true,
            "current": "98000000"
          },
          "options": {
            "government": true,
            "foreignTaxes": false,
            "sourceFunds": true,
            "foreignCurrency": {
              "status": true,
              "export": false,
              "import": true,
              "services": false,
              "others": false,
              "country": {
                "id": "US",
                "value": "United States of America"
              }
            }
          },
          "additional": {
            "alreadyKnow": true,
            "allowance": {
              "id": "002",
              "value": "Mi Casa Ya"
            },
            "affiliated": {
              "status": true,
              "agreement": {
                "id": "002",
                "value": "Caja Honor"
              }
            }
          }
        },
        "contact": {
          "firstName": "Daniel",
          "lastName": "Giraldo",
          "email": "mail@mail.com",
          "phone": "3001234567",
          "policies": true,
          "dateTime": "2022-02-18T13:50:15-05:00"
        },
        "isCompleteApplication": true
      };
  
    let res = http.post(url, JSON.stringify(data), { headers: headers });
     check(res, {
      "status is 201": r => r.status === 200,
      "responseCode": r => r.json()["responseCode"] === 1000
    });



  console.log("Segundo: " + valueToken);
  console.log("------------------------------------------------------");
};