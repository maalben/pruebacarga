import http from 'k6/http';
import * as globals from '../Globals/Logger.js'
import { sleep, check, group, fail } from 'k6';
//import { Counter } from 'k6/metrics';

// A simple counter for http requests

export function setup() {
  globals.headersLogs();
}

//export const requests = new Counter('http_reqs');

// you can specify stages of your test (ramp up/down patterns) through the options object
// target is the number of VUs you are aiming for

export const options = {
  stages: [
    { target: 5, duration: '1m' },
    { target: 3, duration: '1m' },
    { target: 0, duration: '1m' },
  ]
/*   ,
  thresholds: {
    http_reqs: ['count < 100'],
  }, */
};

export default function () {

  group('REquest web page k6', function () {

    const res = http.get('https://reqres.in/api/users?id=1');
  
    check(res, {'status is 200': r => r.status === 200});
    sleep(1);
    globals.logged(__VU, __ITER, res);

  });

  group('REquest 22222 web page k6', function () {

    const res = http.get('https://reqres.in/api/users?id=2');
  
    check(res, {'status is 200': r => r.status === 200});
    sleep(1);
    globals.logged(__VU, __ITER, res);
  
    });

}
