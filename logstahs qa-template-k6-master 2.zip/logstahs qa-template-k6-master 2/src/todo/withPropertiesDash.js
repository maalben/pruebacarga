import http from 'k6/http';
import { sleep, check, group, fail } from 'k6';

export const options = {
  stages: [
    { target: 1, duration: '5s' }
  ],
  thresholds: {
    http_reqs: ['count < 30'],
  },
};

export default function () {

    
  const url = 'https://httpbin.test.k6.io/post';
  let headers = { 'Content-Type': 'application/json' };

  let res = http.post(url, 'Hello world!', { headers: headers });
   check(res, {
    "status is 201": r => r.status === 200
  });

/* console.log("json: " + res.json().headers.Host);
console.log("json: " + res.json().headers["X-Scheme"]);
console.log("json: " + JSON.stringify(res.json()["headers"]["X-Scheme"])); */

}
