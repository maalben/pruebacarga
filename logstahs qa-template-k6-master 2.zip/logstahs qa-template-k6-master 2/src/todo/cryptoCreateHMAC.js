//https://k6.io/docs/javascript-api/k6-crypto/createhmac/
import crypto from 'k6/crypto';

export default function () {
  console.log(crypto.hmac('sha256', 'a secret', 'my data', 'hex'));
  const hasher = crypto.createHMAC('sha256', 'a secret');
  hasher.update('my ');
  hasher.update('data');
  console.log(hasher.digest('hex'));
}
