//https://k6.io/docs/using-k6/thresholds/
import http from 'k6/http';
import { check } from "k6";
import { textSummary } from "https://jslib.k6.io/k6-summary/0.0.2/index.js";

export const options = {
    stages: [
        { target: 10, duration: '10s' }
      ],
  thresholds: {
    http_req_failed: ['rate<0.01'], // http errors should be less than 1%
    http_req_duration: ['p(95)<2000'], // 95% of requests should be below 200ms
  },
};

export default function () {
  let res;
res =  http.get('https://test-api.k6.io/public/crocodiles/1/');

check(res, {"status is 200": r => r.status === 200})
console.log("status1: " + res.status);
}

export function handleSummary(data) {
  return {
    stdout: textSummary(data, { indent: '→', enableColors: true }),
    './summary.json': JSON.stringify(data),
  };
}

