//https://k6.io/docs/javascript-api/k6-http/response/response-submitform/
import http from 'k6/http';
import { sleep } from 'k6';

export default function () {
  // Request page containing a form
  let res = http.get('https://httpbin.test.k6.io/forms/post');

  // Now, submit form setting/overriding some fields of the form
  res = res.submitForm({
    formSelector: 'form',
    fields: { custnamexxx: 'test', custtelxxx: 'test2' },
  });
  sleep(3);
}
