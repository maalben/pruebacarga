//https://k6.io/docs/javascript-api/k6-metrics/counter/
import http from 'k6/http';
import { Counter } from 'k6/metrics';

const CounterErrors = new Counter('Errors');

export const options = { 
    stages: [
        { target: 5, duration: '7s' }
      ],
    thresholds: { 
        Errors: ['count<100'] 
    } 
};

export default function () {
  const res = http.get('https://test-api.k6.io/public/crocodiles/1/');
  const contentOK = res.json('name') === 'Berts';
  CounterErrors.add(!contentOK);
}