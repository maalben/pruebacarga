
let d = new Date();

export function loadFullDate(){

    let currentDay;

    if((d.getHours()-5) < 10){
        currentDay = "0"+(d.getHours()-5);
    }else{
        currentDay = (d.getHours()-5);
    }

    return d.getFullYear()+""+(d.getMonth()+1)+""+d.getDate()+"-"+currentDay+""+d.getMinutes()+""+d.getSeconds();

}