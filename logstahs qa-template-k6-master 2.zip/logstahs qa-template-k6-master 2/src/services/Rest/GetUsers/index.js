import * as getListUsers from './getListUsers.js'
import * as globals from '../../../Globals/Logger.js'
import * as general_data from '../../General/general.js'
import * as dataListUsers from './setupGetUsers.js'
import { check, group, sleep, fail } from 'k6';

export let options = dataListUsers.parametrization_test[__ENV .TYPE_TEST]

export function setup() {
  globals.headersLogs();
}

export default function(data) {
  let res = getListUsers.execute(data)

  check(res, { 'Status is 200': r => r.status === 200 })
  sleep(1)
  globals.logged(__VU, __ITER, res);
}

export function teardown(data) {
}
