import http from 'k6/http'
import * as general_data from '../../General/general.js'

const HEADERS = {
  headers: {
    "Content-Type": "application/json",
    "Accept": "application/json"
  }
}

export let execute = (data) => {
  const url = `${general_data.base_url_req_res}`

  return http.get(url)
}
