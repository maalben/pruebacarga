import * as postUser from './postUser.js';
import * as globals from '../../../Globals/Logger.js';
import * as cognito from '../../General/cognito.js';
import * as general_data from '../../General/general.js';
import * as setupPostUser from './setupPostUser.js';
import { check, group, sleep, fail } from 'k6';

export let options = setupPostUser.parametrization_test[__ENV.TYPE_TEST];
export let TOKEN = 'Valor Inicial';

export function setup(){
    globals.headersLogs();
    let resAuth = cognito.aut_cognito(general_data.clientID.ENTITY_TWO,general_data.clientSecret.ENTITY_TWO);
    return {data: resAuth.json()};
}

export default function(data){
    let res = postUser.execute(data);
    check(res, {'Status is 200': r => r.status === 200});
    sleep(1);
    globals.logged(__VU, __ITER, res);
}

export function teardown(){
}