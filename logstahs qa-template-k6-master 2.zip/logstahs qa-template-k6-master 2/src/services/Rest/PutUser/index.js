import * as putUser from './putUser.js'
import * as globals from '../../../Globals/Logger.js'
import * as cognito from '../../General/cognito.js'
import * as general_data from '../../General/general.js'
import * as setupPutUsers from './setupPutUser.js'
import { check, group, sleep, fail } from 'k6';

export let options = setupPutUsers.parametrization_test[__ENV .TYPE_TEST]
export let TOKEN = 'Valor Inicial'

export function setup() {
  globals.headersLogs();
  let resAuth = cognito.aut_cognito(general_data.clientID.ENTITY_ONE, general_data.clientSecret.ENTITY_ONE)
  return {data: resAuth.json() };
}

export default function(data) {
  let res = putUser.execute(data)
  check(res, { 'status is 200': r => r.status === 200 })
  sleep(1)
  globals.logged(__VU, __ITER, res);
}

export function teardown(data) {
}
