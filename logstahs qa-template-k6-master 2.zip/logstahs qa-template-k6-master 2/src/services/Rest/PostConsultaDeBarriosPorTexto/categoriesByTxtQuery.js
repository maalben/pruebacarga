import http from 'k6/http';
import * as globals from '../../../Globals/Logger.js';
import * as general_data from '../../General/general.js';
import { check, sleep } from 'k6';
import * as proccessTemplateBody from './templateRequest.js';
import * as proccessTemplateHeader from './templatePostHeader.js';
import * as proccessData from './loadData.js';

const csvData = proccessData.dataLoaded();

export function makeQueryNeighborhoodByText(){

    const url = `${general_data.base_url_queries}`

    let headers = proccessTemplateHeader.loadHeaderTemplate();

    const randomData = csvData[(__ITER)]; //Iniciar de arriba hacia abajo
    //const randomData = csvData[csvData.length-(__ITER+1)]; //Si se requiere iniciar de abajo hacia arriba

    let body = proccessTemplateBody.loadBodyTemplate(`${general_data.neighboorhood_by_text}`, randomData.limit, randomData.txt);

    let response = http.post(url, JSON.stringify(body), { headers: headers });

    //Imprimir request que se envía para validar qué está armando
    check(response, {
      'status is 200': (r) => r.status === 200,
      'responseCode is 1000': (r) => r.json().responseCode === 1000,
      'message is Operation performed successfully': (r) => r.json().message === "Operation performed successfully"
    });

    sleep(1)

    globals.logged(__VU, __ITER, response);
  };