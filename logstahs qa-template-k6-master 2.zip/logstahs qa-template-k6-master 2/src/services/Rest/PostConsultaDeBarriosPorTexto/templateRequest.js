

export function loadBodyTemplate(type, valueLimit, valueText){

    return {
        "queries" : [
          {
              "types" : [type],
              "filter" : {
                  "key" : {
                      "values" : ["NBH"]
                  },
                  "limit" : {
                      "values" : [valueLimit]
                  },
                  "txt" : {
                      "values" : [valueText]
                  },
                  "cityId" : {
                      "values" : ["1"]
                  },
                  "geo" : false         
              }            
          }
        ]
      };
    
}