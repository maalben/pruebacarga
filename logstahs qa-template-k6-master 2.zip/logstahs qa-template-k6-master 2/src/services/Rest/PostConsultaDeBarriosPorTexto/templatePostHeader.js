

export function loadHeaderTemplate(){

    return { 
        'Content-Type': 'application/json',
        'x-api-key': '8ddbjUOaOO1YpMAJgDmyl4flakl8Uat04CXKUpvV'
    };
    
}