import * as getProducts from './getProducts.js'
import * as globals from '../../../Globals/Logger.js'
import * as token from '../../General/token.js'
import * as setupGetProducts from './setupGetProducts.js'
import { check, group, sleep, fail } from 'k6';

export let options = setupGetProducts.parametrization_test[__ENV .TYPE_TEST]

export function setup(){
  globals.headersLogs();
  let resAuth = token.get_token();
  return {data: resAuth.json()};
}

export default function(data){
  let res = getProducts.execute(data);
  check(res, {'Status is 200': r => r.status === 200});
  globals.logged(__VU, __ITER, res);
}

export function teardown(data) {
}
