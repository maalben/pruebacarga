import http from "k6/http";
import * as general_data from '../../General/general.js'

var HEADERS =  {
    headers: { 
      'Authorization' : '',
      'x-device-serial' : `${general_data.deviceSerial}`
    }
}

export let execute = (data) => {
  const url = `${general_data.base_url}${general_data.costumer_products}`

  HEADERS.headers['Authorization'] = 'Bearer ' + data.data.token

  return http.get(
    url,
    HEADERS
  )
}