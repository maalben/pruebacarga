module.exports = {
    "parametrization_test": {
        "smoke_test": {
            vus: 1,  // 1 user looping for 1 minute
            duration: '10s',
            thresholds: {
                'http_req_duration': ['p(99)<150000'], // 99% of requests must complete below 1.5s
            },
            tags: {
                stack: 'GETs',   // variable de entorno
                layer: 'TestGets',   // variable de entorno
                env: 'qa',    // variable de entorno
                service: 'Test User App',
                type_test: 'smoke_test'
            },
        }
    }
}
