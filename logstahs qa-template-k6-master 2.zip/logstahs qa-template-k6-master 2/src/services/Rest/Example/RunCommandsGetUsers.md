## Ejecución de los tipos de pruebas de Performance para el servicio de Productos

- smoke_test
```
    docker-compose run --rm k6 run -e TYPE_TEST=smoke_test \
    /src/services/Rest/Example/index.js \
    --logformat=raw --console-output=/results/smoke_test_$(date +%Y%m%d-%H%M%S).log 
```
