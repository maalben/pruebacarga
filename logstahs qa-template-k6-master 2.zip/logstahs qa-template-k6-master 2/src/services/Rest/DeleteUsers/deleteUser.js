import http from "k6/http";
import * as general_data from '../../General/general.js'
import setupDeleteUser, * as setupDelete from './setupDeleteUser.js'

const HEADERS = {
  headers: {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "Header-1": "Value Header 1",
    "Header-2": "Value Header 2",
    "Header-3": "Value Header 3",
    "Header-4": "Value Header 4",
    "Header-5": "Value Header 5"
  }
}

  export let execute = (data) => {
      const url = `${general_data.base_url}${setupDeleteUser.url}`

      const TOKEN = data.data.access_token

      HEADERS.headers['X-RqUID'] = Math.floor(Math.random() * 1000000)
      HEADERS.headers['Authorization'] = 'Bearer ' + TOKEN

      return http.del(url,
         HEADERS
        )
  }