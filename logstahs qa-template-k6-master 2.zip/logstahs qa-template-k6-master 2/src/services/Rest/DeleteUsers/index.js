import * as deleteUser from './deleteUser.js';
import * as globals from '../../../Globals/Logger.js';
import * as cognito from '../../General/cognito.js';
import * as general_data from '../../General/general.js';
import * as setupDeleteUser from './setupDeleteUser.js';
import { check, group, sleep, fail } from 'k6';

export let options = setupDeleteUser.parametrization_test[__ENV.TYPE_TEST];
export let TOKEN = 'Valor Inicial';

export function setup(){
    globals.headersLogs();
    let resAuth = cognito.aut_cognito(general_data.clientID.ENTITY_TWO,general_data.clientSecret.ENTITY_TWO);
    return {data: resAuth.json()};
}

export default function(data){
    let res = deleteUser.execute(data);
    check(res, {'status is 204': r => r.status === 204});
    sleep(1);
    globals.logged(__VU, __ITER, res);
}

export function teardown(){
}