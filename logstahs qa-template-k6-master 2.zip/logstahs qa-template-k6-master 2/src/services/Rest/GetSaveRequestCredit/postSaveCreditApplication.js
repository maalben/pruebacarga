import http from 'k6/http'
import * as globals from '../../../Globals/Logger.js';
import * as general_data from '../../General/general.js'
import { check, sleep } from 'k6';

export function makeCreditApplication(valueSid, valueToken){
    const url = `${general_data.base_url_credit_application}`
      let headers = { 
            'Content-Type': 'application/json',
            'x-custom-token': valueToken,
            'x-session-id': valueSid
        };
      let data = 
      {
        "personal": {
          "identification": {
            "type": {
              "id": "CC",
              "value": "Cédula de ciudadanía"
            },
            "document": "{{document}}"
          },
          "expeditionDate": "2002-02-02",
          "expeditionCity": {
            "name": "ARMENIA",
            "daneCode": "63001",
            "departmentDaneCode": "63",
            "departmentName": "QUINDIO"
          },
          "birthDate": "1980-03-03",
          "birthCity": {
            "name": "CALI",
            "daneCode": "76001",
            "departmentDaneCode": "76",
            "departmentName": "VALLE DEL CAUCA"
          },
          "civilStatus": {
            "id": "2",
            "value": "Casado"
          },
          "gender": {
            "id": "1",
            "value": "Masculino"
          }
        },
        "housing": {
          "city": {
            "name": "CARTAGENA DE INDIAS",
            "daneCode": "13001",
            "departmentDaneCode": "13",
            "departmentName": "BOLIVAR"
          },
          "address": "Dirección de residencia actual",
          "alternativeAddress": "Complemento dirección de residencia actual",
          "type": {
            "id": "3",
            "value": "Propia"
          },
          "yearOfLiving": 8
        },
        "work": {
          "educationalLevel": {
            "id": "5",
            "value": "Postgrado"
          },
          "activity": {
            "id": "1",
            "value": "Empleado"
          },
          "career": {
            "id": "12230",
            "value": "Directores y gerentes de ingeniería, investigación y desarrollo"
          },
          "company": {
            "sector": {
              "id": "2",
              "value": "Privado"
            },
            "name": "Banco de Occidente",
            "activity": {
              "id": "5",
              "value": "Financiero"
            },
            "city": {
              "name": "CALI",
              "daneCode": "76001",
              "departmentDaneCode": "76",
              "departmentName": "VALLE DEL CAUCA"
            },
            "address": "Dirección empresa",
            "alternativeAddress": "Complemento dirección empresa",
            "phone": "3164440038",
            "position": "Gerente de TI",
            "entryDate": "2009-12-05",
            "contractType": {
              "id": "02",
              "value": "Término indefinido"
            }
          }
        },
        "financial": {
          "income": "30500000",
          "additionalIncome": "2800000",
          "discounts": "5600000",
          "expenses": "6000000",
          "dependants": 1,
          "totalAssets": "1550000000",
          "totalLiabilities": "120000000",
          "properties": {
            "status": true,
            "current": "1200000000"
          },
          "vehicles": {
            "status": true,
            "current": "230000000"
          },
          "otherAssets": {
            "status": true,
            "current": "98000000"
          },
          "options": {
            "government": true,
            "foreignTaxes": false,
            "sourceFunds": true,
            "foreignCurrency": {
              "status": true,
              "export": false,
              "import": true,
              "services": false,
              "others": false,
              "country": {
                "id": "US",
                "value": "United States of America"
              }
            }
          },
          "additional": {
            "alreadyKnow": true,
            "allowance": {
              "id": "002",
              "value": "Mi Casa Ya"
            },
            "affiliated": {
              "status": true,
              "agreement": {
                "id": "002",
                "value": "Caja Honor"
              }
            }
          }
        },
        "contact": {
          "firstName": "Daniel",
          "lastName": "Giraldo",
          "email": "mail@mail.com",
          "phone": "3001234567",
          "policies": true,
          "dateTime": "2022-02-18T13:50:15-05:00"
        },
        "isCompleteApplication": true
      };
    
      let response = http.post(url, JSON.stringify(data), { headers: headers });
      check(response, {
        'status is 200': (r) => r.status === 200,
        'responseCode is 1000': (r) => r.json().responseCode === 1000,
        'message is Operation performed successfully': (r) => r.json().message === "Operation performed successfully"
      });
    sleep(1)
    globals.logged(__VU, __ITER, response);
  };