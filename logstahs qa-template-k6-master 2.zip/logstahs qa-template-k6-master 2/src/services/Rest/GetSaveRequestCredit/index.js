import { htmlReport } from "https://raw.githubusercontent.com/benc-uk/k6-reporter/main/dist/bundle.js";
import { textSummary } from "https://jslib.k6.io/k6-summary/0.0.1/index.js";
import * as globals from '../../../Globals/Logger.js';
import * as executionType from './setup.js';
import * as initialToken from './getToken.js';
import * as sessionId from './getSessionId.js';
import * as creditApplication from './postSaveCreditApplication.js';
import { group } from 'k6';

export let options = executionType.parametrization_test[__ENV .TYPE_TEST]

export function setup() {
  globals.headersLogs();
}

export default function() {
  let tokenizer;
  let sid;
  group("1 - Get initial token", function() {tokenizer = initialToken.getToken()});
  group("2 - Get session id", function(){sid = sessionId.getSessionId(tokenizer)});
  group("3 - Post make demo credit application", function(){creditApplication.makeCreditApplication(sid, tokenizer)});
}

export function handleSummary(data) {
  console.log("A reportar");
  console.log(data);
  return {
    "/results/result.json": JSON.stringify(data),
    "/results/result.html": htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}

export function teardown(data) {

}
