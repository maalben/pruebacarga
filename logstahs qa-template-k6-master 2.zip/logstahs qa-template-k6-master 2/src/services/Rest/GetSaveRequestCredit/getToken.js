import http from 'k6/http'
import * as general_data from '../../General/general.js'
import * as globals from '../../../Globals/Logger.js';
import { check, sleep } from 'k6';
//import { Trend } from 'k6/metrics';

//const myTrend = new Trend('waiting_time');

export function getToken(){
  let url = `${general_data.base_url_token}`
  let response = http.get(url);

  let token = response.json().data.searchUrl.substring(60, 1000);
  check(response, {
    'status is 200': (r) => r.status === 200,
    'responseCode is 1000': (r) => r.json().responseCode === 1000,
    'message is Operation performed successfully': (r) => r.json().message === "Operation performed successfully"
  });
  
  //myTrend.add(response.timings.waiting);
  //    console.log(myTrend.name+"-getToken:"+response.timings.waiting);
  sleep(1)
  globals.logged(__VU, __ITER, response);
  return token;
};