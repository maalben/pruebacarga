module.exports = {
    "parametrization_test": {
        "stress_test": {
            stages: [
                { duration: '2m', target: 10 }, // below normal load
                { duration: '5m', target: 10 },
                { duration: '2m', target: 20 }, // normal load
                { duration: '5m', target: 20 },
                { duration: '2m', target: 30 }, // around the breaking point
                { duration: '5m', target: 30 },
                { duration: '2m', target: 40 }, // beyond the breaking point
                { duration: '5m', target: 40 },
                { duration: '10m', target: 0 }, // scale down. Recovery stage.
            ],
            thresholds: {
                http_req_duration: ['p(99)<1500'], // 99% of requests must complete below 1.5s
                http_req_failed: ['rate<0.01'], // http errors should be less than 1%
            },
            tags: {
                stack: 'GETs',
                layer: 'TEST',
                env: 'qa',
                service: 'Test User App',
                type_test: 'stress_test'
            }
        },
        "load_test": {
            stages: [
              { duration: '1m', target: 5 }, // below normal load
              { duration: '1m', target: 10 }, // normal load
              { duration: '1m', target: 15 }, // around the breaking point
              { duration: '1m', target: 20 }, // beyond the breaking point
              { duration: '1m', target: 15 }, // scale down. Recovery stage.
              { duration: '1m', target: 10 }, // scale down. Recovery stage.
              { duration: '1m', target: 5 }, // scale down. Recovery stage.
              { duration: '1m', target: 0 }, // scale down. Recovery stage.
            ],
            thresholds: {
                http_req_duration: ['p(99)<1500'] // 99% of requests must complete below 1.5s
            },
            tags: {
                stack: 'GETs',     // variable de entorno
                layer: 'TestGets',     // variable de entorno
                env: 'qa',      // variable de entorno
                service: 'Test User App',
                type_test: 'load_test'
            }
        },
        "endurance_test": {
            stages: [
                { duration: '2m', target: 40 }, // ramp up to 400users
                { duration: '3h56m', target: 40 }, // stay at 40 for ~4 hours
                { duration: '2m', target: 0 }, // scale down. (optional)
            ],
            thresholds: {
                http_req_duration: ['p(99)<1500'], // 99% of requests must complete below 1.5s
            },
            tags: {
                stack: 'Gets',   // variable de entorno
                layer: 'TestGets',   // variable de entorno
                env: 'qa',    // variable de entorno
                service: 'Test User App',
                type_test: 'smoke_test'
            }
        },
        "peak_test": {
            stages: [
                { duration: '2m', target: 10, rps: 5 },
                { duration: '5m', target: 10, rps: 5 },
                { duration: '30s', target: 22, rps: 11 },
                { duration: '30s', target: 14, rps: 7 },
                { duration: '5m', target: 14, rps: 7 },
                { duration: '2m', target: 10, rps: 5 },
                { duration: '1m', target: 10, rps: 5 },
                { duration: '1m', target: 0, rps: 2 }
            ],
            thresholds: {
                http_req_duration: ['p(99)<1500'], // 99% of requests must complete below 1.5s
            },
            tags: {
                stack: 'GETs',
                layer: 'TEST',
                env: 'qa',
                service: 'Test User App',
                type_test: 'stress_test'
            }
        },
        "scenario_test": {
            stages: [
                { duration: '5m', target: 60 }, // simulate ramp-up of traffic from 1 to 60 users over 5 minutes.
                { duration: '10m', target: 60 }, // stay at 60 users for 10 minutes
                { duration: '3m', target: 100 }, // ramp-up to 100 users over 3 minutes (peak hour starts)
                { duration: '2m', target: 100 }, // stay at 100 users for short amount of time (peak hour)
                { duration: '3m', target: 60 }, // ramp-down to 60 users over 3 minutes (peak hour ends)
                { duration: '10m', target: 60 }, // continue at 60 for additional 10 minutes
                { duration: '5m', target: 0 }, // ramp-down to 0 users
            ],
            thresholds: {
                http_req_duration: ['p(99)<1500'], // 99% of requests must complete below 1.5s
            },
            tags: {
                stack: 'GETs',
                layer: 'TEST',
                env: 'qa',
                service: 'Test User App',
                type_test: 'stress_test'
            }
        },
        "smoke_test": {
            vus: 1,  // 1 user looping for 10 seconds
            duration: '10s',
            rps: 1,
            thresholds: {
                'http_req_duration': ['p(99)<1500'], // 99% of requests must complete below 1.5s
            },
            tags: {
                stack: 'GETs',   // variable de entorno
                layer: 'TestGets',   // variable de entorno
                env: 'qa',    // variable de entorno
                service: 'Test User App',
                type_test: 'smoke_test'
            },
        }
    }
}
