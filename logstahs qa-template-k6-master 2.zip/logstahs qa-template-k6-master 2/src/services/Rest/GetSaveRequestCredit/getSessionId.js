import http from 'k6/http'
import * as globals from '../../../Globals/Logger.js';
import * as general_data from '../../General/general.js'
import { check, sleep } from 'k6';

export function getSessionId(token){
  let url = `${general_data.base_url_session_id}`
  let params = {
    headers: { 'x-custom-token': token }
  };
  let response = http.get(url, params);
  let session = response.json().data.sessionId
  check(response, {
    'status is 200': (r) => r.status === 200,
    'responseCode is 1000': (r) => r.json().responseCode === 1000,
    'message is Operation performed successfully': (r) => r.json().message === "Operation performed successfully"
  });
  sleep(1)
  globals.logged(__VU, __ITER, response);
  return session;
};