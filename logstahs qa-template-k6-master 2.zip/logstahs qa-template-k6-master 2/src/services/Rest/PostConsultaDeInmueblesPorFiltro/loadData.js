import papaparse from 'https://jslib.k6.io/papaparse/5.1.1/index.js';
import { SharedArray } from 'k6/data';

export function dataLoaded(){

const pathFileDataCsv = "../../../resources/data_neighborhood.csv";    

return new SharedArray('Datos para el request', function () {
    return papaparse.parse(open(pathFileDataCsv), { header: true }).data;
  });

}