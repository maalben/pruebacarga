## OBTENER LISTA DE USUARIOS REQ-RES

- smoke_test
```
    docker-compose run --rm k6  run -e TYPE_TEST=smoke_test \
      --logformat=raw --console-output=/results/smoke_test_$(date +%Y%m%d-%H%M%S).log\
      --http-debug="full" \
      /src/services/Rest/GetSaveRequestCredit/index.js
```

- tps_test
```
    docker-compose run --rm k6 run -e TYPE_TEST=tps_test \
      --logformat=raw --console-output=/results/tps_test_$(date +%Y%m%d-%H%M%S).log \
      /src/services/Rest/GetSaveRequestCredit/index.js
```

- constant_vus
```
    docker-compose run --rm k6  run -e TYPE_TEST=constant_vus \
      --logformat=raw --console-output=/results/constant_vus_$(date +%Y%m%d-%H%M%S).log \
      /src/services/Rest/GetSaveRequestCredit/index.js
```

- load_test
```
    docker-compose run --rm k6  run -e TYPE_TEST=load_test \
      --logformat=raw --console-output=/results/load_test_$(date +%Y%m%d-%H%M%S).log \
      /src/services/Rest/GetSaveRequestCredit/index.js
```

 - stress_test
 ```
     docker-compose run --rm k6  run -e TYPE_TEST=stress_test \
      --logformat=raw --console-output=/results/stress_test_$(date +%Y%m%d-%H%M%S).log \
      /src/services/Rest/GetSaveRequestCredit/index.js
```
