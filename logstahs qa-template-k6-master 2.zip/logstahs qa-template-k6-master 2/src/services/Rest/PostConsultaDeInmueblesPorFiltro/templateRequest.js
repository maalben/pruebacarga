

export function loadBodyTemplate(type){

    return {
        "queries": [
            {
                "batch": {
                    "realEstate": {
                        "from": 0
                    },
                    "seller": {
                        "from": 0
                    }
                },
                "types": [
                    type
                ],
                "filter": {
                    "businessTypeId": {
                        "values": [
                            "1","2","3"
                        ]
                    },
                    "priceRange": {
                        "values": [
                            "1",
                            "50000000000000"
                        ]
                    },
                    "propertyTypeId": {
                        "values": [
                            "1","2","3","4","5","6","7","8","9","10","11","12","13","14"
                        ]
                    },
                    "status": {
                        "values": [
                            "Usado"
                        ]
                    }
                }
            }
        ]
    };
}