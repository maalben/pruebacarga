import { htmlReport } from "https://raw.githubusercontent.com/benc-uk/k6-reporter/main/dist/bundle.js";
import { textSummary } from "https://jslib.k6.io/k6-summary/0.0.1/index.js";
import * as globals from '../../../Globals/Logger.js';
import * as executionType from './setup.js';
import * as processQuery from './propertiesByFiltersQuery.js';
import * as utilDate from '../../../utils/FullDate.js';
import { group } from 'k6';

export let options = executionType.parametrization_test[__ENV.TYPE_TEST]

export function setup() {
  globals.headersLogs();
}

export default function() {
  group("1 - Post make query properties by filter", function(){processQuery.makeQueryByFilter()});
}

export function handleSummary(data) {
  return {
    [`/results/${__ENV.TYPE_TEST+"_"+utilDate.loadFullDate()}.json`]: JSON.stringify(data),
    [`/results/${__ENV.TYPE_TEST+"_"+utilDate.loadFullDate()}.html`]: htmlReport(data),
    stdout: textSummary(data, { indent: " ", enableColors: true }),
  };
}

export function teardown(data) {

}