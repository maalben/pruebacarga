import http from 'k6/http';
import * as globals from '../../../Globals/Logger.js';
import * as general_data from '../../General/general.js';
import { check, sleep } from 'k6';
import * as proccessTemplate from './templateRequest.js';
import * as proccessData from './loadData.js';

const csvData = proccessData.dataLoaded();

export function makeQueryByFilter(){

    const url = `${general_data.base_url_queries}`

    let headers = { 
          'Content-Type': 'application/json',
          'x-api-key': '8ddbjUOaOO1YpMAJgDmyl4flakl8Uat04CXKUpvV'
    };

    const randomData = csvData[(__ITER)]; //Iniciar de arriba hacia abajo
    //const randomData = csvData[csvData.length-(__ITER+1)]; //Si se requiere iniciar de abajo hacia arriba

    let body = proccessTemplate.loadBodyTemplate(`${general_data.filter_properties}`);

    let response = http.post(url, JSON.stringify(body), { headers: headers });

    check(response, {
      'status is 200': (r) => r.status === 200,
      'responseCode is 1000': (r) => r.json().responseCode === 1000,
      'message is Operation performed successfully': (r) => r.json().message === "Operation performed successfully"
    });

    sleep(1)

    globals.logged(__VU, __ITER, response);
  };