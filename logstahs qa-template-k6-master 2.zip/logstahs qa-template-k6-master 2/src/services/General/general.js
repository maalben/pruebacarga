export const base_url_req_res = "https://reqres.in/api/users/1";

//Simulación de solicitud de crédito de vivienda
export const base_url_token = "https://jnxicxtvy9.execute-api.us-east-2.amazonaws.com/v1/api/personal/tokens";
export const base_url_session_id = "https://personal-dev-api.metrocuadrado.com/v1/api/personal/sessions";
export const base_url_credit_application = "https://personal-dev-api.metrocuadrado.com/v1/api/personal/credit-application";

//Consulta de barrios por texto
export const base_url_queries = "https://kq3721jap6.execute-api.us-east-2.amazonaws.com/v1/api/commons/queries"
export const neighboorhood_by_text = "categoriesByTxtQuery"
export const filter_properties = "propertiesByFiltersQuery"
