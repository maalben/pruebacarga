import http from 'k6/http'
import * as general_data from './general.js'

export function get_token(clientID, clientSecret) {

  var headers = {
    headers: {
      'Content-Type': 'application/json'
    }
  }

  const body = {
    "documentNumber": `${general_data.docuemntNumber}`,
    "password": `${general_data.password}`,
    "documentType": `${general_data.documentType}`,
    "deviceSerial": `${general_data.deviceSerial}`
  }

  const url = `${general_data.base_url}${general_data.token_authentication_url}`;

  return http.post(
    url,
    JSON.stringify(body) ,
    headers
  )
}