# Automatización - Pruebas de performance - <Proyecto>

[![Git](https://img.shields.io/badge/Git-v2.29.X-green.svg)](https://git-scm.com/downloads) [![Docker](https://img.shields.io/badge/Docker-v3.1.X-green.svg)](https://www.docker.com/products/docker-desktop/)
[![Grafana](https://img.shields.io/badge/Grafana-v8.4.X-green.svg)](https://hub.docker.com/r/grafana/grafana) [![influxdb](https://img.shields.io/badge/Influxdb-v1.8.X-yellow.svg)](https://hub.docker.com/_/influxdb)

>Este proyecto contiene las pruebas de carga realizadas a las APIS para <Proyecto>

## Tabla de Contenido

- [:key: Pre-requisitos](#prerequisites)
- [:wrench: Instalacion](#installation)
- [:whale: Docker - Compose](#quickstart)
- [:runner: Ejecucion de Pruebas](#contributing)
- [:page_facing_up: Resultado de las Pruebas](#further-reading--useful-links)

## :key: Pre-requisitos

Necesitara tener instalado correctamente en su computador las siguientes herramientas:

* [Git](http://git-scm.com/)
* [Docker](https://docs.docker.com/desktop/)

## :wrench: Instalacion

Para Clonar este repositorio ejecutar en su terminal:

```
git clone git@github.avaldigitallabs.com:avaldigitallabs/bocc-pb-qa-k6.git
```

Ingresar al proyecto a través

```
cd bocc-pb-qa-k6
```

## :whale: Docker - Compose

Iniciar los contenedores de **Influxbd** y **Grafana** para la visualización de resultados.

```
docker-compose up -d influxdb grafana
```

Para validar que los contenedores estan en ejecución correr el siguiente comando:

```
docker ps
```

Debe resultar 2 contenedores nombrados **qa-template-k6_grafana_1** y **qa-template-k6_influxdb_1**

El contenedor de k6 se inicia al momento de correr la prueba con el comando.

## :runner: Ejecucion de Pruebas

Para realizar la ejecución de pruebas, se corre el siguiente comando de acuerdo al escenario:

```
    docker-compose run k6 run -e TYPE_TEST=<TipoTest> \
      --logformat=raw --console-output=/results/<NombreArchivoResultado>_$(date +%Y%m%d-%H%M%S).log \
      <ScriptTest>
```

Variables a tener en cuenta:

- **TipoTest:** Tipo de prueba que se va a ejecutar deacuerdo a escenarios planteados en archivo setup
- **NombreArchivoResultado:** Prefijo del archivo de resultados que se va a guardar en la carpeta de Results
- **ScriptTest:** Ruta del archivo index.js que va a orquestar la prueba

##### Ejemplo de Ejecución:

- **tps_test**
```
    docker-compose run k6 run -e TYPE_TEST=tps_test \
      --logformat=raw --console-output=/results/tps_test_$(date +%Y%m%d-%H%M%S).log \
      /src/REST/services/Products/index.js
```

## :page_facing_up: Resultado de las Pruebas

#### :watch: Archivo de Log de Resultados

Los resultados en archivo plano se guardaran en la carpeta `results/_nombre_API_/_tipo_de_prueba_${TimeStamp}`.

#### :computer: Grafana

Los resultados tambien se pueden observar en los tableros de grafana en la siguiente ruta:

http://localhost:3000/d/k6/k6-load-testing-results

