# Process

This document is to describe the internal process that the ${PROJECT_NAME} uses for issue management, project planning and the development workflow.


## Workflow

### Overview


- `master`: completed features, bug fixes, refactors, chores


#### Master Branch




### Feature Branches



### Release Branches



### Hotfix Branches

